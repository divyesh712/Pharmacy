import React from 'react';
import { StatusBar } from 'react-native';

export default function MyStatusBar(props) {

        return (
            <StatusBar
                translucent={true}
                hidden={true}
            />
        );   
}
