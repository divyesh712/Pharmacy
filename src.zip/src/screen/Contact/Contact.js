import React, { useRef, useState } from 'react';
import { View, Text, Image, TextInput, StyleSheet, TouchableOpacity, } from 'react-native';

const Contact = (props) => {
    return(
        <View>
            <Text>
                Contact
            </Text>
        </View>
    )
}

export default Contact;
