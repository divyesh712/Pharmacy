import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

export default fontFamily = {
    BLACK_FONT_FAMILY : "Poppins-SemiBold", //-------->600px
    BOLD_FONT_FAMILY : "Poppins-Medium",  //------> 500px
    REGULAR_FORT_FAMILY : "Poppins-Regular", //------>400px
}