export const color = {
    bg_main : '#fff',
    mainfont : '#000000',
    secondfont : "rgba(0, 0, 0, 0.6)",
    thirdfont : " rgba(0, 0, 0, 0.8)",
    darkgrey : "#6A6A6A",
    secondary_bg : "#DFF1F9",
    borderColor : "rgba(0, 0, 0, 0.13)",
    light_bg : '#EFFAFF',
    highlighfont : "#49A542",
    countColor : "#FDEFDC",
    lineColor : '#B3B3B3',
    secondLineColor : "#DEDEDE"
}